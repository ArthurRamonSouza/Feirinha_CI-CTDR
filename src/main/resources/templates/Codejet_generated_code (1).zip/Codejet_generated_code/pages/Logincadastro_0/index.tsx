import "./style.css";
import { Frame2 as Frame2_0 } from "./Frame2_0";
import { Rectangle18 as Rectangle18_0 } from "assets/Rectangle18_0";
import { Rectangle19 as Rectangle19_0 } from "assets/Rectangle19_0";
import { TEXT } from "components/TEXT";
import { Frame3 as Frame3_0 } from "./Frame3_0";
import { FeirinhaLogoremovebg2 as FeirinhaLogoremovebg2_0 } from "assets/FeirinhaLogoremovebg2_0";
import { Cadastrarbtn as Cadastrarbtn_0 } from "./Cadastrarbtn_0";

export const Logincadastro = () => {
  return (
    <div className="Logincadastro_1_7">
      <Frame2_0 />
      <Rectangle18_0 />
      <Rectangle19_0 />
      <TEXT characters="E-mail" className="TEXT_19_74" />
      <TEXT characters="Senha" className="TEXT_18_13" />
      <TEXT characters="Não tem cadastro? " className="TEXT_18_15" />
      <TEXT characters="Cadastre-se aqui" className="TEXT_19_76" />
      <Frame3_0 />
      <FeirinhaLogoremovebg2_0 />
      <Cadastrarbtn_0 />
    </div>
  );
};
