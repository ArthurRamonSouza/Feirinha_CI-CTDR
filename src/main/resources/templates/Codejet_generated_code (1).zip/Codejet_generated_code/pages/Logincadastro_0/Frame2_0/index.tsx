import "./style.css";
import { Image5 as Image5_0 } from "assets/Image5_0";
import { TEXT } from "components/TEXT";

export const Frame2 = () => {
  return (
    <div className="Frame2_19_62">
      <Image5_0 />
      <TEXT characters="LOGIN" className="TEXT_9_13" />
    </div>
  );
};
