import "./style.css";

export const Frame3 = () => {
  return <div className="Frame3_66_2"></div>;
};
