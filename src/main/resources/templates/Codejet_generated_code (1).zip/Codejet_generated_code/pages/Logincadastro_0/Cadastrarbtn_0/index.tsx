import "./style.css";
import { Rectangle4 as Rectangle4_0 } from "assets/Rectangle4_0";
import { TEXT } from "components/TEXT";

export const Cadastrarbtn = () => {
  return (
    <div className="Cadastrarbtn_94_26">
      <Rectangle4_0 />
      <TEXT characters="Login" className="TEXT_94_28" />
    </div>
  );
};
