export const Image5 = () => {
  return (
    <svg
      style={{
        zIndex: 1,
        borderRadius: "256px",
      }}
      width="164"
      height="154"
      viewBox="0 0 164 154"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="4fa696a2e4eb64ebde44d3efb6f7a6c0e35bf56a"
          patternUnits="userSpaceOnUse"
          width="164"
          height="154"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/4fa6/96a2/e4eb64ebde44d3efb6f7a6c0e35bf56a?Expires=1697414400&Signature=YuFz30DnrODYXpKto2AASokonLatfb70i~9csX08w4FJrtUXJSqx0CJFH4EzZKCUdg3KQ36yQN6NKWK8S8yd0idNRfcioUdjIEUF3jDq2rhON94Dv5dXvqmB-1pFLGlt8NUYU6y8S5TCDp0pXmv60eQUWZiJvTD1X70PYt~Wf8~zimGfP6Y~0CjUBcG4xgXkyQT0y3nkr9B0vtm9E1dnoGQIs~1g633mSbUbirHybPoT8ekjPQTOfv1VIWYhMDdafXan5PG8bKAR1QNXXNsZLygAsFHsAuqu-~tQP03GDclSUzdmKdtt8X93hawARQnpeeyjuq1zL5UJC3aHpPJKfg__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="164"
            height="154"
          />
        </pattern>
      </defs>
      <path
        d="M0 77C0 34.4741 34.4741 0 77 0L87 0C129.526 0 164 34.4741 164 77L164 77C164 119.526 129.526 154 87 154L77 154C34.4741 154 0 119.526 0 77L0 77Z"
        fill="url(#4fa696a2e4eb64ebde44d3efb6f7a6c0e35bf56a)"
      />
    </svg>
  );
};
