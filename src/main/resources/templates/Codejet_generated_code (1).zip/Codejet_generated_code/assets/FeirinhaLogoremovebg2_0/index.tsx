export const FeirinhaLogoremovebg2 = () => {
  return (
    <svg
      style={{
        transform:
          "translate(2.842170943040401e-14px, -117px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="408"
      height="429"
      viewBox="0 0 408 429"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="c8a514822e0ed37f00cc81428fca6d914acca7da"
          patternUnits="userSpaceOnUse"
          width="408"
          height="429"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/c8a5/1482/2e0ed37f00cc81428fca6d914acca7da?Expires=1697414400&Signature=q4an94Ks5yUyRD1MOcvTY4R90Hl3ZzpqeJs7D63Z8nJVkWuaUmFArh-NUZG9JTsYgMhIdLayX-sFyVufnxUBLsqk24jsVpuhxvNRe6knhPKalyiRWs07YFunJYrjC9LjotlT4yC2HBwLmU0FLhKs53xunM4-UAYxZZn5nsg5qaYLc1XQVe5I-tPr6IBZzJFxAZaD1OReZ73kMqMyQRhzMyBYilkYNTI2nbOCni5c3fnQ-SyZdYJ2L2imZQY1xouquzR9z3hTKWf-QWquNJ~GvKPSDVSDm0~MSpaTG08ch0HpnqhiyYZdye73YTV75T1H6IgHJQg2QOEHfEEOh1fb1g__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="408"
            height="429"
          />
        </pattern>
      </defs>
      <path
        d="M0 0L408 0L408 429L0 429L0 0Z"
        fill="url(#c8a514822e0ed37f00cc81428fca6d914acca7da)"
      />
    </svg>
  );
};
