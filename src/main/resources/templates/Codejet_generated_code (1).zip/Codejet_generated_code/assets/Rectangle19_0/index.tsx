export const Rectangle19 = () => {
  return (
    <svg
      style={{
        transform: "translate(737px, 561px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        filter: "drop-shadow(0px 4px 2px rgba(0, 0, 0, 0.325))",
        borderRadius: "25px",
      }}
      width="461"
      height="107"
      viewBox="-1 -1 461 107"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M25 1L434 1L434 -1L25 -1L25 1ZM458 25L458 80L460 80L460 25L458 25ZM434 104L25 104L25 106L434 106L434 104ZM1 80L1 25L-1 25L-1 80L1 80ZM25 104C11.7452 104 1 93.2548 1 80L-1 80C-1 94.3594 10.6406 106 25 106L25 104ZM458 80C458 93.2548 447.255 104 434 104L434 106C448.359 106 460 94.3594 460 80L458 80ZM434 1C447.255 1 458 11.7452 458 25L460 25C460 10.6406 448.359 -1 434 -1L434 1ZM25 -1C10.6406 -1 -1 10.6406 -1 25L1 25C1 11.7452 11.7452 1 25 1L25 -1Z"
        fill="rgba(122.1874974668026, 118.62369909882545, 118.62369909882545, 1)"
      />
      <path
        d="M0 25C0 11.1929 11.1929 0 25 0L434 0C447.807 0 459 11.1929 459 25L459 80C459 93.8071 447.807 105 434 105L25 105C11.1929 105 0 93.8071 0 80L0 25Z"
        fill="rgba(255, 255, 255, 1)"
      />
    </svg>
  );
};
