export const Rectangle6 = () => {
  return (
    <svg
      style={{
        transform:
          "translate(808px, 0.00006866455078125px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "30px",
      }}
      width="161"
      height="152"
      viewBox="0 0 161 152"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 30C0 13.4315 13.4315 0 30 0L131 0C147.569 0 161 13.4315 161 30L161 122C161 138.569 147.569 152 131 152L30 152C13.4315 152 0 138.569 0 122L0 30Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
