export const Rectangle12 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 0px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "30px",
      }}
      width="258"
      height="255"
      viewBox="0 0 258 255"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 30C0 13.4315 13.4315 0 30 0L228 0C244.569 0 258 13.4315 258 30L258 225C258 241.569 244.569 255 228 255L30 255C13.4315 255 0 241.569 0 225L0 30Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
