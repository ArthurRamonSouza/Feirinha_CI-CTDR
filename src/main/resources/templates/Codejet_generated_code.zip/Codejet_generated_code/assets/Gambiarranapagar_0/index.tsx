export const Gambiarranapagar = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 0px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="76"
      height="84"
      viewBox="0 0 76 84"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 0L76 0L76 84L0 84L0 0Z"
        fill="rgba(243.00000071525574, 242.00000077486038, 240.00000089406967, 1)"
      />
    </svg>
  );
};
