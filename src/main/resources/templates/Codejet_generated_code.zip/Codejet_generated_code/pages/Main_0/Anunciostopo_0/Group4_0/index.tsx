import "./style.css";
import { Rectangle14 as Rectangle14_0 } from "assets/Rectangle14_0";
import { TEXT } from "components/TEXT";

export const Group4 = () => {
  return (
    <div className="Group4_1_200">
      <Rectangle14_0 />
      <TEXT characters="Anuncio" className="TEXT_1_198" />
      <TEXT characters="R$300" className="TEXT_1_199" />
    </div>
  );
};
