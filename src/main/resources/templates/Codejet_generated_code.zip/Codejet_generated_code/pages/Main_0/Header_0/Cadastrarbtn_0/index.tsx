import "./style.css";
import { Rectangle4 as Rectangle4_1 } from "assets/Rectangle4_1";
import { TEXT } from "components/TEXT";

export const Cadastrarbtn = () => {
  return (
    <div className="Cadastrarbtn_1_45">
      <Rectangle4_1 />
      <TEXT characters="Cadastrar" className="TEXT_1_44" />
    </div>
  );
};
