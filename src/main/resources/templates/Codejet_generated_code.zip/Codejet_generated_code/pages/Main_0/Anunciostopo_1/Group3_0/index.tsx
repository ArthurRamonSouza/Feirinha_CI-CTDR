import "./style.css";
import { Rectangle12 as Rectangle12_1 } from "assets/Rectangle12_1";
import { TEXT } from "components/TEXT";

export const Group3 = () => {
  return (
    <div className="Group3_1_202">
      <Rectangle12_1 />
      <TEXT characters="Anuncio" className="TEXT_1_204" />
      <TEXT characters="R$300" className="TEXT_1_205" />
    </div>
  );
};
