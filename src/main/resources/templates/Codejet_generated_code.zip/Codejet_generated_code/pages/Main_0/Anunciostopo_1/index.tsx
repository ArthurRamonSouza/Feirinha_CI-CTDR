import "./style.css";
import { Group3 as Group3_0 } from "./Group3_0";
import { Group2 as Group2_0 } from "./Group2_0";
import { Group4 as Group4_0 } from "./Group4_0";
import { Anuncio2 as Anuncio2_0 } from "./Anuncio2_0";
import { Anuncio1 as Anuncio1_0 } from "./Anuncio1_0";

export const Anunciostopo = () => {
  return (
    <div className="Anunciostopo_1_201">
      <Group3_0 />
      <Group2_0 />
      <Group4_0 />
      <Anuncio2_0 />
      <Anuncio1_0 />
    </div>
  );
};
