import "./style.css";
import { Rectangle12 as Rectangle12_0 } from "assets/Rectangle12_0";
import { TEXT } from "components/TEXT";

export const Group3 = () => {
  return (
    <div className="Group3_1_197">
      <Rectangle12_0 />
      <TEXT characters="Anuncio" className="TEXT_1_195" />
      <TEXT characters="R$300" className="TEXT_1_196" />
    </div>
  );
};
