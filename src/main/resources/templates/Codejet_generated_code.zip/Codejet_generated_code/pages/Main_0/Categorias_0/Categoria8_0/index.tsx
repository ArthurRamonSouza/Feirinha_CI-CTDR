import "./style.css";
import { Ellipse8 as Ellipse8_0 } from "assets/Ellipse8_0";
import { TEXT } from "components/TEXT";

export const Categoria8 = () => {
  return (
    <div className="Categoria8_6_41">
      <Ellipse8_0 />
      <TEXT characters="categoria" className="TEXT_6_40" />
    </div>
  );
};
