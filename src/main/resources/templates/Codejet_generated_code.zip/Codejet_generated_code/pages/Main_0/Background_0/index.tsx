import "./style.css";
import { Gambiarranapagar as Gambiarranapagar_0 } from "assets/Gambiarranapagar_0";

export const Background = () => {
  return (
    <div className="Background_6_47">
      <Gambiarranapagar_0 />
    </div>
  );
};
