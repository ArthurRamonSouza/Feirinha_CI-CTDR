import "./style.css";
import { Rectangle13 as Rectangle13_1 } from "assets/Rectangle13_1";
import { TEXT } from "components/TEXT";

export const Group2 = () => {
  return (
    <div className="Group2_1_206">
      <Rectangle13_1 />
      <TEXT characters="Anuncio" className="TEXT_1_208" />
      <TEXT characters="R$300" className="TEXT_1_209" />
    </div>
  );
};
