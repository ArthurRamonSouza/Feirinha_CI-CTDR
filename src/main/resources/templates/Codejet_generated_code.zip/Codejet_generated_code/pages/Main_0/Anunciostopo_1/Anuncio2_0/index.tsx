import "./style.css";
import { TEXT } from "components/TEXT";

export const Anuncio2 = () => {
  return (
    <div className="Anuncio2_1_214">
      <TEXT characters="Anuncio" className="TEXT_1_215" />
      <TEXT characters="R$300" className="TEXT_1_216" />
    </div>
  );
};
