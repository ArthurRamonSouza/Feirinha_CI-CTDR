import "./style.css";
import { VendendoHoje as VendendoHoje_0 } from "assets/VendendoHoje_0";
import { Rectangle6 as Rectangle6_0 } from "assets/Rectangle6_0";
import { Rectangle7 as Rectangle7_0 } from "assets/Rectangle7_0";
import { VendendoHoje as VendendoHoje_1 } from "assets/VendendoHoje_1";
import { VendendoHoje as VendendoHoje_2 } from "assets/VendendoHoje_2";
import { VendendoHoje as VendendoHoje_3 } from "assets/VendendoHoje_3";
import { VendendoHoje as VendendoHoje_4 } from "assets/VendendoHoje_4";

export const Group1 = () => {
  return (
    <div className="Group1_6_20">
      <VendendoHoje_0 />
      <Rectangle6_0 />
      <Rectangle7_0 />
      <VendendoHoje_1 />
      <VendendoHoje_2 />
      <VendendoHoje_3 />
      <VendendoHoje_4 />
    </div>
  );
};
