import "./style.css";
import { Group1 as Group1_0 } from "./Group1_0";

export const Vendendohoje = () => {
  return (
    <div className="Vendendohoje_6_21">
      <Group1_0 />
    </div>
  );
};
