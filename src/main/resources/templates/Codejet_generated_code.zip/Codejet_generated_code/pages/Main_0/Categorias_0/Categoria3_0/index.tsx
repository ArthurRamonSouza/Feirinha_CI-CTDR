import "./style.css";
import { Ellipse1 as Ellipse1_0 } from "assets/Ellipse1_0";
import { TEXT } from "components/TEXT";

export const Categoria3 = () => {
  return (
    <div className="Categoria3_1_173">
      <Ellipse1_0 />
      <TEXT characters="categoria" className="TEXT_1_168" />
    </div>
  );
};
