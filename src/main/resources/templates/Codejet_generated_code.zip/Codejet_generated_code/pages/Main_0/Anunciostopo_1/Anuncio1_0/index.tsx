import "./style.css";
import { Rectangle11 as Rectangle11_1 } from "assets/Rectangle11_1";
import { TEXT } from "components/TEXT";
import { Rectangle10 as Rectangle10_1 } from "assets/Rectangle10_1";

export const Anuncio1 = () => {
  return (
    <div className="Anuncio1_1_217">
      <Rectangle11_1 />
      <TEXT characters="Anuncio" className="TEXT_1_219" />
      <TEXT characters="R$300" className="TEXT_1_220" />
      <Rectangle10_1 />
    </div>
  );
};
