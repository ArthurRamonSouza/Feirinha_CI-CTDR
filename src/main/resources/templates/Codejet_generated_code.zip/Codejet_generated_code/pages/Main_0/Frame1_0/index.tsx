import "./style.css";

export const Frame1 = () => {
  return <div className="Frame1_1_77"></div>;
};
