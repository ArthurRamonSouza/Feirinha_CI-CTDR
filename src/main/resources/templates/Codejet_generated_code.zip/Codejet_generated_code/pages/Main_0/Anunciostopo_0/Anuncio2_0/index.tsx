import "./style.css";
import { TEXT } from "components/TEXT";

export const Anuncio2 = () => {
  return (
    <div className="Anuncio2_1_189">
      <TEXT characters="Anuncio" className="TEXT_1_187" />
      <TEXT characters="R$300" className="TEXT_1_188" />
    </div>
  );
};
