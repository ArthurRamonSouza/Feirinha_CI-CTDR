import "./style.css";
import { Rectangle3 as Rectangle3_0 } from "assets/Rectangle3_0";
import { Lupa as Lupa_0 } from "assets/Lupa_0";

export const Barradebusca = () => {
  return (
    <div className="Barradebusca_1_49">
      <Rectangle3_0 />
      <Lupa_0 />
    </div>
  );
};
