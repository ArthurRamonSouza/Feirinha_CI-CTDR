import "./style.css";
import { Ellipse7 as Ellipse7_0 } from "assets/Ellipse7_0";
import { TEXT } from "components/TEXT";

export const Categoria7 = () => {
  return (
    <div className="Categoria7_6_42">
      <Ellipse7_0 />
      <TEXT characters="categoria" className="TEXT_9_4" />
    </div>
  );
};
