import "./style.css";
import { Categoria1 as Categoria1_0 } from "./Categoria1_0";
import { Categoria2 as Categoria2_0 } from "./Categoria2_0";
import { Categoria3 as Categoria3_0 } from "./Categoria3_0";
import { Categoria8 as Categoria8_0 } from "./Categoria8_0";
import { Categoria7 as Categoria7_0 } from "./Categoria7_0";
import { Categoria6 as Categoria6_0 } from "./Categoria6_0";
import { Categoria5 as Categoria5_0 } from "./Categoria5_0";
import { Categoria4 as Categoria4_0 } from "./Categoria4_0";

export const Categorias = () => {
  return (
    <div className="Categorias_1_68">
      <Categoria1_0 />
      <Categoria2_0 />
      <Categoria3_0 />
      <Categoria8_0 />
      <Categoria7_0 />
      <Categoria6_0 />
      <Categoria5_0 />
      <Categoria4_0 />
    </div>
  );
};
