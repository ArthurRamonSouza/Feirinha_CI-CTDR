import "./style.css";
import { Rectangle4 as Rectangle4_0 } from "assets/Rectangle4_0";
import { TEXT } from "components/TEXT";

export const Anunciarbtn = () => {
  return (
    <div className="Anunciarbtn_1_46">
      <Rectangle4_0 />
      <TEXT characters="Anunciar" className="TEXT_1_48" />
    </div>
  );
};
