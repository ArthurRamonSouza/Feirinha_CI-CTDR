import "./style.css";
import { Ellipse4 as Ellipse4_0 } from "assets/Ellipse4_0";
import { TEXT } from "components/TEXT";

export const Categoria4 = () => {
  return (
    <div className="Categoria4_6_45">
      <Ellipse4_0 />
      <TEXT characters="categoria" className="TEXT_6_37" />
    </div>
  );
};
