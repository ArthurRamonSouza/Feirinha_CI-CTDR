import "./style.css";
import { Barradebusca as Barradebusca_0 } from "./Barradebusca_0";
import { Anunciarbtn as Anunciarbtn_0 } from "./Anunciarbtn_0";
import { Cadastrarbtn as Cadastrarbtn_0 } from "./Cadastrarbtn_0";
import { Feirinhalogo as Feirinhalogo_0 } from "assets/Feirinhalogo_0";

export const Header = () => {
  return (
    <div className="Header_6_46">
      <Barradebusca_0 />
      <Anunciarbtn_0 />
      <Cadastrarbtn_0 />
      <Feirinhalogo_0 />
    </div>
  );
};
