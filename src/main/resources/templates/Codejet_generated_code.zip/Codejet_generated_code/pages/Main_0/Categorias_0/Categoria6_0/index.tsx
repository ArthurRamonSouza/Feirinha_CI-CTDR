import "./style.css";
import { Ellipse2 as Ellipse2_0 } from "assets/Ellipse2_0";
import { TEXT } from "components/TEXT";

export const Categoria6 = () => {
  return (
    <div className="Categoria6_6_43">
      <Ellipse2_0 />
      <TEXT characters="categoria" className="TEXT_6_39" />
    </div>
  );
};
