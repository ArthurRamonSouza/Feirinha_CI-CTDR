import "./style.css";
import { Background as Background_0 } from "./Background_0";
import { Header as Header_0 } from "./Header_0";
import { Anunciostopo as Anunciostopo_0 } from "./Anunciostopo_0";
import { Anunciostopo as Anunciostopo_1 } from "./Anunciostopo_1";
import { Anunciosbaixo as Anunciosbaixo_0 } from "./Anunciosbaixo_0";
import { Categorias as Categorias_0 } from "./Categorias_0";
import { Vendendohoje as Vendendohoje_0 } from "./Vendendohoje_0";
import { Frame1 as Frame1_0 } from "./Frame1_0";

export const Main = () => {
  return (
    <div className="Main_1_52">
      <Background_0 />
      <Header_0 />
      <Anunciostopo_0 />
      <Anunciostopo_1 />
      <Anunciosbaixo_0 />
      <Categorias_0 />
      <Vendendohoje_0 />
      <Frame1_0 />
    </div>
  );
};
