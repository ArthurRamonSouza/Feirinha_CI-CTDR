import "./style.css";
import { TEXT } from "components/TEXT";
import { Ellipse3 as Ellipse3_0 } from "assets/Ellipse3_0";

export const Categoria5 = () => {
  return (
    <div className="Categoria5_6_44">
      <TEXT characters="categoria" className="TEXT_6_38" />
      <Ellipse3_0 />
    </div>
  );
};
