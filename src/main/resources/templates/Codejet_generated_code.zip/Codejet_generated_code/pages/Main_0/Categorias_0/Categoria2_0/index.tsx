import "./style.css";
import { Ellipse6 as Ellipse6_0 } from "assets/Ellipse6_0";
import { TEXT } from "components/TEXT";

export const Categoria2 = () => {
  return (
    <div className="Categoria2_1_172">
      <Ellipse6_0 />
      <TEXT characters="categoria" className="TEXT_1_167" />
    </div>
  );
};
