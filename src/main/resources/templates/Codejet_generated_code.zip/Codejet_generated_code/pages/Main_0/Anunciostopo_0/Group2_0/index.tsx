import "./style.css";
import { Rectangle13 as Rectangle13_0 } from "assets/Rectangle13_0";
import { TEXT } from "components/TEXT";

export const Group2 = () => {
  return (
    <div className="Group2_1_194">
      <Rectangle13_0 />
      <TEXT characters="Anuncio" className="TEXT_1_192" />
      <TEXT characters="R$300" className="TEXT_1_193" />
    </div>
  );
};
