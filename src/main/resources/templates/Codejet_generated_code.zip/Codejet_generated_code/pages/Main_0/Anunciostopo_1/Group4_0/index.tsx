import "./style.css";
import { Rectangle14 as Rectangle14_1 } from "assets/Rectangle14_1";
import { TEXT } from "components/TEXT";

export const Group4 = () => {
  return (
    <div className="Group4_1_210">
      <Rectangle14_1 />
      <TEXT characters="Anuncio" className="TEXT_1_212" />
      <TEXT characters="R$300" className="TEXT_1_213" />
    </div>
  );
};
