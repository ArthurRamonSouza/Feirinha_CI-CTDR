import "./style.css";
import { Rectangle11 as Rectangle11_0 } from "assets/Rectangle11_0";
import { TEXT } from "components/TEXT";
import { Rectangle10 as Rectangle10_0 } from "assets/Rectangle10_0";

export const Anuncio1 = () => {
  return (
    <div className="Anuncio1_1_186">
      <Rectangle11_0 />
      <TEXT characters="Anuncio" className="TEXT_1_180" />
      <TEXT characters="R$300" className="TEXT_1_181" />
      <Rectangle10_0 />
    </div>
  );
};
