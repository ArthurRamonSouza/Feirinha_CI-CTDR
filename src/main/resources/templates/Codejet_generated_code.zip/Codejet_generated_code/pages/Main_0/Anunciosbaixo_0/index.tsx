import "./style.css";
import { Rectangle10 as Rectangle10_2 } from "assets/Rectangle10_2";
import { Rectangle12 as Rectangle12_2 } from "assets/Rectangle12_2";
import { Rectangle14 as Rectangle14_2 } from "assets/Rectangle14_2";
import { Rectangle11 as Rectangle11_2 } from "assets/Rectangle11_2";

export const Anunciosbaixo = () => {
  return (
    <div className="Anunciosbaixo_1_174">
      <Rectangle10_2 />
      <Rectangle12_2 />
      <Rectangle14_2 />
      <Rectangle11_2 />
    </div>
  );
};
