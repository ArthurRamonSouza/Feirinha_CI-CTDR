import "./style.css";
import { Ellipse9 as Ellipse9_0 } from "assets/Ellipse9_0";
import { TEXT } from "components/TEXT";

export const Categoria1 = () => {
  return (
    <div className="Categoria1_1_171">
      <Ellipse9_0 />
      <TEXT characters="categoria" className="TEXT_1_165" />
    </div>
  );
};
