export const Rectangle4 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 116px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "116px",
      }}
      width="342"
      height="116"
      viewBox="0 0 342 116"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 58C0 25.9675 25.9675 0 58 0L284 0C316.033 0 342 25.9675 342 58L342 58C342 90.0325 316.033 116 284 116L58 116C25.9675 116 0 90.0325 0 58L0 58Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
