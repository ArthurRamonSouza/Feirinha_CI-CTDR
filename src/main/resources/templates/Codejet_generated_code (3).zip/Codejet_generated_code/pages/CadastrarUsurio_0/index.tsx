import "./style.css";
import { Rectangle18 as Rectangle18_0 } from "assets/Rectangle18_0";
import { Rectangle19 as Rectangle19_0 } from "assets/Rectangle19_0";
import { TEXT } from "components/TEXT";
import { Rectangle20 as Rectangle20_0 } from "assets/Rectangle20_0";
import { FeirinhaLogoremovebg1 as FeirinhaLogoremovebg1_0 } from "assets/FeirinhaLogoremovebg1_0";
import { Cadastrarbtn as Cadastrarbtn_0 } from "./Cadastrarbtn_0";

export const CadastrarUsurio = () => {
  return (
    <div className="CadastrarUsurio_41_2">
      <Rectangle18_0 />
      <Rectangle19_0 />
      <TEXT characters="E-mail" className="TEXT_41_10" />
      <Rectangle20_0 />
      <TEXT characters="Matrícula" className="TEXT_94_12" />
      <TEXT characters="Senha" className="TEXT_41_11" />
      <FeirinhaLogoremovebg1_0 />
      <TEXT
        characters="Crie a sua conta e faça parte da feirinha mais quente da UFPB!"
        className="TEXT_94_10"
      />
      <TEXT characters="CADASTRE-SE!" className="TEXT_94_15" />
      <Cadastrarbtn_0 />
      <TEXT characters="Já tem uma conta? Entrar " className="TEXT_94_19" />
    </div>
  );
};
