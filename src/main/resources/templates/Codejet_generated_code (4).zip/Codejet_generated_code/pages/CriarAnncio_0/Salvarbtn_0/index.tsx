import "./style.css";
import { Rectangle4 as Rectangle4_0 } from "assets/Rectangle4_0";
import { TEXT } from "components/TEXT";

export const Salvarbtn = () => {
  return (
    <div className="Salvarbtn_127_26">
      <Rectangle4_0 />
      <TEXT characters="Salvar" className="TEXT_127_28" />
    </div>
  );
};
