import "./style.css";
import { Rectangle21 as Rectangle21_0 } from "assets/Rectangle21_0";
import { Rectangle22 as Rectangle22_0 } from "assets/Rectangle22_0";
import { TEXT } from "components/TEXT";
import { Rectangle23 as Rectangle23_0 } from "assets/Rectangle23_0";
import { Rectangle25 as Rectangle25_0 } from "assets/Rectangle25_0";
import { Frame6 as Frame6_0 } from "./Frame6_0";
import { FeirinhaLogoremovebg2 as FeirinhaLogoremovebg2_0 } from "assets/FeirinhaLogoremovebg2_0";
import { Salvarbtn as Salvarbtn_0 } from "./Salvarbtn_0";
import { Cancelarbtn as Cancelarbtn_0 } from "./Cancelarbtn_0";

export const CriarAnncio = () => {
  return (
    <div className="CriarAnncio_41_67">
      <Rectangle21_0 />
      <Rectangle22_0 />
      <TEXT characters="Descrição" className="TEXT_110_4" />
      <Rectangle23_0 />
      <Rectangle25_0 />
      <TEXT characters="Título" className="TEXT_110_6" />
      <TEXT characters="Localização" className="TEXT_113_6" />
      <TEXT characters="Preço" className="TEXT_110_7" />
      <TEXT characters="Fotos" className="TEXT_110_11" />
      <TEXT characters="Criar anúncio" className="TEXT_113_2" />
      <Frame6_0 />
      <TEXT characters="Adicionar fotos" className="TEXT_115_13" />
      <FeirinhaLogoremovebg2_0 />
      <Salvarbtn_0 />
      <Cancelarbtn_0 />
    </div>
  );
};
