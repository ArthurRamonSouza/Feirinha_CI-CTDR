export const Image20 = () => {
  return (
    <svg
      style={{
        transform: "translate(106px, 79px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="114"
      height="109"
      viewBox="0 0 114 109"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="34be767a8089cbcf6efce18242dde4fc34e60a46"
          patternUnits="userSpaceOnUse"
          width="114"
          height="109"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/34be/767a/8089cbcf6efce18242dde4fc34e60a46?Expires=1697414400&Signature=AfEyHfDXqCCFqAJQBFlLNDZel3Fg~cS0~HnlAjymuymhXfSZr1K9BxXNDIKtNlrjNTsxNbmAJXtAQ-aaIFFbfhRUFyeD8IqEtxxoSx6e6K76sh1PM2xcNF-ZS3x4TGV3XYgoOD15HcNKG-o0~X8UNkHIfBOrZJKVyImpJx2HkUbpDTEvrALcxaPt4Y8UBSMZt3HUpx-HMTsswpzXw3VE6aqJPCJ2LcnzoBkpXwcqN7~WFYnWWUFy0SdbYVueVtJn7Ev6DgV2s1YFdX~Wio9M-OfeAMD1FQYYJpAJnwX-yi0-sklzPOhQ-K3MNlN~UhL6HFvZ2vyTwmO5t48QFqsR1Q__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="114"
            height="109"
          />
        </pattern>
      </defs>
      <path
        d="M0 0L114 0L114 109L0 109L0 0Z"
        fill="url(#34be767a8089cbcf6efce18242dde4fc34e60a46)"
      />
    </svg>
  );
};
