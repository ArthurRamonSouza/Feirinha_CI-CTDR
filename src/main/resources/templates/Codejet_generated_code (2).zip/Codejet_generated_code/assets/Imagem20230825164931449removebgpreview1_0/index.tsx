export const Imagem20230825164931449removebgpreview1 = () => {
  return (
    <svg
      style={{
        transform: "translate(12px, 4.5px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="48"
      height="49"
      viewBox="0 0 48 49"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="d6605da4d495c44ed670d2a41dac5c86b568ce41"
          patternUnits="userSpaceOnUse"
          width="48"
          height="49"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/d660/5da4/d495c44ed670d2a41dac5c86b568ce41?Expires=1697414400&Signature=gpNDTZugjsB-ItxbNGACk8AWnaWrc7dQWgvo7S0S6lHDnfFAq73AkAdgsnLk4fnZaeeGiLIjUt62uh1pqeqveqR5A83UeS0OOEmeNgAtJD1HlTW4NREY4yLCh1XiV9wvqQnuuTn09pa0n43OGvh1fEtp~dlX8tvzv9hSIEYfyY0piQXiyQZUINgHdemScLpwGSDf1bGnrKMf50ZFJR-0ZkHisw3mjXOADx9zecvgjnLJ8QZcdcWDMhUwk2amZroRAAAVseKTAXud~JHm8lHo1pBHtgQn-By3brKsuF8icejsdN2yRUXKXvGtM6YO-5LjQXp8ripMnikpnPi-0eWq8w__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="48"
            height="49"
          />
        </pattern>
      </defs>
      <path
        d="M0 0L48 0L48 49L0 49L0 0Z"
        fill="url(#d6605da4d495c44ed670d2a41dac5c86b568ce41)"
      />
    </svg>
  );
};
