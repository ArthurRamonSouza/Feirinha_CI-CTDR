export const Rectangle21 = () => {
  return (
    <svg
      style={{
        transform: "translate(251px, 297px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "40px",
      }}
      width="854"
      height="460"
      viewBox="0 0 854 460"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 40C0 17.9086 17.9086 0 40 0L814 0C836.091 0 854 17.9086 854 40L854 420C854 442.091 836.091 460 814 460L40 460C17.9086 460 0 442.091 0 420L0 40Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
