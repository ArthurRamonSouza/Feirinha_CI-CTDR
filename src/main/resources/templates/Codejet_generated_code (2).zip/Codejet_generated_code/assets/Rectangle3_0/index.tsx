export const Rectangle3 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 108px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "116px",
      }}
      width="826"
      height="108"
      viewBox="0 0 826 108"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 54C0 24.1766 24.1766 0 54 0L772 0C801.823 0 826 24.1766 826 54L826 54C826 83.8234 801.823 108 772 108L54 108C24.1766 108 0 83.8234 0 54L0 54Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
