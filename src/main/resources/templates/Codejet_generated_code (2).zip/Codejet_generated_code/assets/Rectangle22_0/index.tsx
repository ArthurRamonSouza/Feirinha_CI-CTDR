export const Rectangle22 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 0px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "47px",
      }}
      width="402"
      height="620"
      viewBox="0 0 402 620"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 47C0 21.0426 21.0426 0 47 0L355 0C380.957 0 402 21.0426 402 47L402 573C402 598.957 380.957 620 355 620L47 620C21.0426 620 0 598.957 0 573L0 47Z"
        fill="rgba(217.0000022649765, 217.0000022649765, 217.0000022649765, 1)"
      />
    </svg>
  );
};
