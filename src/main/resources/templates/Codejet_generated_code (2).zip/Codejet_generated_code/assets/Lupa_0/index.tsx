export const Lupa = () => {
  return (
    <svg
      style={{
        transform: "translate(45px, 30px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "18px",
      }}
      width="61"
      height="58"
      viewBox="0 0 61 58"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id="245a1da552c515909ed83ac4563bfd02aa083e4b"
          patternUnits="userSpaceOnUse"
          width="61"
          height="58"
        >
          <image
            href="https://s3-alpha-sig.figma.com/img/245a/1da5/52c515909ed83ac4563bfd02aa083e4b?Expires=1697414400&Signature=SLlJ2MgXN5P~BXCtQ07N4dvVqFSDs9MfB4iV2p02g8qpMqeDwQDYmyC7P3Xq8yHEyM6jYw2ie-aWtKi84pfnsjUJypl8AgVqeEC-bTpELASfDaj3Os4h6ru24KhsUb0Wgf5F7U7B0bTXkENXys1ZhAO2MqeKfPI0cntbiVUHbKpEFvcRJF9P1inHmZ7JiFXhOejQAorUGx2FqvpmDrNOZqP0MzbrAKlvIsfQfNJqFZtLbXEz9qB9G04IKgBXMyKgKF0t~mu-72P-bIi8lEPGNvXA91MXbhUICdV6hwjFIKP5V~Bltb~sxTC8Mmde02OlS949HQ0Qe1Q-9QFVueMtiw__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4"
            x="0"
            y="0"
            width="61"
            height="58"
          />
        </pattern>
      </defs>
      <path
        d="M0 18C0 8.05887 8.05888 0 18 0L43 0C52.9411 0 61 8.05887 61 18L61 40C61 49.9411 52.9411 58 43 58L18 58C8.05888 58 0 49.9411 0 40L0 18Z"
        fill="url(#245a1da552c515909ed83ac4563bfd02aa083e4b)"
      />
    </svg>
  );
};
