export const Ellipse10 = () => {
  return (
    <svg
      style={{
        transform: "translate(147px, 59px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="129"
      height="129"
      viewBox="0 0 129 129"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M129 64.5C129 100.122 100.122 129 64.5 129C28.8776 129 0 100.122 0 64.5C0 28.8776 28.8776 0 64.5 0C100.122 0 129 28.8776 129 64.5Z"
        fill="rgba(138.1250050663948, 130.06770461797714, 130.06770461797714, 1)"
      />
    </svg>
  );
};
