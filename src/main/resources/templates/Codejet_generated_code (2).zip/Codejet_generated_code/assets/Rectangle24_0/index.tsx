export const Rectangle24 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 0px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
        borderRadius: "11px",
      }}
      width="217"
      height="60"
      viewBox="0 0 217 60"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 11C0 4.92487 4.92487 0 11 0L206 0C212.075 0 217 4.92487 217 11L217 49C217 55.0751 212.075 60 206 60L11 60C4.92487 60 0 55.0751 0 49L0 11Z"
        fill="rgba(255, 215.0000023841858, 7.000000057742, 1)"
      />
    </svg>
  );
};
