export const Star2 = () => {
  return (
    <svg
      style={{
        transform: "translate(0px, 0px) rotate(0deg) scale(1, 1)",
        transformOrigin: "1px 1px",
        position: "absolute",
        top: 0,
        left: 0,
      }}
      width="40"
      height="40"
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M20 0L24.4903 13.8197L39.0211 13.8197L27.2654 22.3607L31.7557 36.1803L20 27.6393L8.2443 36.1803L12.7346 22.3607L0.97887 13.8197L15.5097 13.8197L20 0Z"
        fill="rgba(211.43749594688416, 204.14284497499466, 29.072656072676182, 1)"
      />
    </svg>
  );
};
