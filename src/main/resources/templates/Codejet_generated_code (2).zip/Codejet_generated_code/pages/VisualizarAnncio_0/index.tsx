import "./style.css";
import { Header as Header_0 } from "./Header_0";
import { Rectangle21 as Rectangle21_0 } from "assets/Rectangle21_0";
import { TEXT } from "components/TEXT";
import { FeirinhaLogoremovebg1 as FeirinhaLogoremovebg1_0 } from "assets/FeirinhaLogoremovebg1_0";
import { Group5 as Group5_0 } from "./Group5_0";

export const VisualizarAnncio = () => {
  return (
    <div className="VisualizarAnncio_41_41">
      <Header_0 />
      <Rectangle21_0 />
      <TEXT characters="Titulo do produto" className="TEXT_89_18" />
      <TEXT characters="R$300" className="TEXT_89_19" />
      <TEXT characters="Descrição do produto" className="TEXT_89_20" />
      <FeirinhaLogoremovebg1_0 />
      <Group5_0 />
    </div>
  );
};
