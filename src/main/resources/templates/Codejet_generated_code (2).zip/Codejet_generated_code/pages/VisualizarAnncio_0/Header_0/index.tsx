import "./style.css";
import { Barradebusca as Barradebusca_0 } from "./Barradebusca_0";
import { Anunciarbtn as Anunciarbtn_0 } from "./Anunciarbtn_0";
import { Perfilbtn as Perfilbtn_0 } from "./Perfilbtn_0";

export const Header = () => {
  return (
    <div className="Header_89_2">
      <Barradebusca_0 />
      <Anunciarbtn_0 />
      <Perfilbtn_0 />
    </div>
  );
};
