import "./style.css";
import { Rectangle4 as Rectangle4_1 } from "assets/Rectangle4_1";
import { TEXT } from "components/TEXT";

export const Perfilbtn = () => {
  return (
    <div className="Perfilbtn_89_10">
      <Rectangle4_1 />
      <TEXT
        characters="Perfil
"
        className="TEXT_89_12"
      />
    </div>
  );
};
