import "./style.css";
import { Rectangle22 as Rectangle22_0 } from "assets/Rectangle22_0";
import { Ellipse10 as Ellipse10_0 } from "assets/Ellipse10_0";
import { TEXT } from "components/TEXT";
import { Estrelinhas as Estrelinhas_0 } from "./Estrelinhas_0";
import { Comprarbtn as Comprarbtn_0 } from "./Comprarbtn_0";

export const Group5 = () => {
  return (
    <div className="Group5_89_38">
      <Rectangle22_0 />
      <Ellipse10_0 />
      <TEXT characters="Nome do vendedor" className="TEXT_89_22" />
      <Estrelinhas_0 />
      <TEXT characters="(83) 99999-9999" className="TEXT_89_29" />
      <Comprarbtn_0 />
    </div>
  );
};
