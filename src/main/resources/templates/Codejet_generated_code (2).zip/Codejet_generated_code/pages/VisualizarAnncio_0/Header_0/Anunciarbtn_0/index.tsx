import "./style.css";
import { Rectangle4 as Rectangle4_0 } from "assets/Rectangle4_0";
import { TEXT } from "components/TEXT";

export const Anunciarbtn = () => {
  return (
    <div className="Anunciarbtn_89_7">
      <Rectangle4_0 />
      <TEXT characters="Anunciar" className="TEXT_89_9" />
    </div>
  );
};
