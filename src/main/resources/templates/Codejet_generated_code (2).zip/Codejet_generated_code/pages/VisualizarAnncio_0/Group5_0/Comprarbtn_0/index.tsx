import "./style.css";
import { Rectangle24 as Rectangle24_0 } from "assets/Rectangle24_0";
import { TEXT } from "components/TEXT";
import { Imagem20230825164931449removebgpreview1 as Imagem20230825164931449removebgpreview1_0 } from "assets/Imagem20230825164931449removebgpreview1_0";

export const Comprarbtn = () => {
  return (
    <div className="Comprarbtn_89_36">
      <Rectangle24_0 />
      <TEXT characters="Comprar" className="TEXT_89_35" />
      <Imagem20230825164931449removebgpreview1_0 />
    </div>
  );
};
