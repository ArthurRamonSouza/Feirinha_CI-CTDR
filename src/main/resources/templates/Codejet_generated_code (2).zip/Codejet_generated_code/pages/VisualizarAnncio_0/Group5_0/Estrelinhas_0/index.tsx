import "./style.css";
import { Star2 as Star2_0 } from "assets/Star2_0";
import { Star3 as Star3_0 } from "assets/Star3_0";
import { Star4 as Star4_0 } from "assets/Star4_0";
import { Star5 as Star5_0 } from "assets/Star5_0";
import { Star1 as Star1_0 } from "assets/Star1_0";

export const Estrelinhas = () => {
  return (
    <div className="Estrelinhas_89_30">
      <Star2_0 />
      <Star3_0 />
      <Star4_0 />
      <Star5_0 />
      <Star1_0 />
    </div>
  );
};
