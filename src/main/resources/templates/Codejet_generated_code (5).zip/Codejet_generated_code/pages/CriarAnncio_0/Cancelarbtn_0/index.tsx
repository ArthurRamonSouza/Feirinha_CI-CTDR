import "./style.css";
import { Rectangle4 as Rectangle4_1 } from "assets/Rectangle4_1";
import { TEXT } from "components/TEXT";

export const Cancelarbtn = () => {
  return (
    <div className="Cancelarbtn_127_29">
      <Rectangle4_1 />
      <TEXT
        characters="Cancelar
"
        className="TEXT_127_31"
      />
    </div>
  );
};
