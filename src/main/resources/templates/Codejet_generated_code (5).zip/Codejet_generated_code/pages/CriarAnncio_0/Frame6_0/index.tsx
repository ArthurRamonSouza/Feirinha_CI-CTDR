import "./style.css";
import { Image20 as Image20_0 } from "assets/Image20_0";

export const Frame6 = () => {
  return (
    <div className="Frame6_113_11">
      <Image20_0 />
    </div>
  );
};
